#ifndef RR_6050_h
#define RR_6050_h

#include <Arduino.h>
#include <Wire.h>

class RR_6050 {
  public:
    // Constructor with default I2C address (0x68)
    RR_6050(uint8_t address = 0x68);
    
    // Initialize the sensor
    void begin();
    
    // Update sensor readings and calculate angles
    void update();
    
    // Calibrate gyroscope (recommended before use)
    void calibrate(uint16_t samples = 500);
    
    // Check if calibration is done
    bool isCalibrated();
    
    // Get Euler angles
    float getYaw() { return yaw; }
    float getPitch() { return pitch; }
    float getRoll() { return roll; }
    
    // Set print interval in milliseconds
    void setPrintInterval(uint16_t interval) { print_interval = interval; }
    
    // Print angles to Serial
    void printData();

  private:
    // Mahony AHRS update
    void mahonyUpdate(float gx, float gy, float gz, float deltat);
    
    // I2C address
    uint8_t MPU_addr;
    
    // Gyro offsets
    float gyroOffsets[3];
    
    // Quaternion
    float quat[4];
    
    // Euler angles
    float yaw, pitch, roll;
    
    // Timing variables
    unsigned long last_print;
    unsigned long last_micros;
    uint16_t print_interval;
    
    // Calibration flag
    bool calibrated;
};

#endif